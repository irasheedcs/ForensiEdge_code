#!/usr/bin/env python3
"""Generate the paper's three figures from training runs.

  Fig. 1  latency vs. number of devices
  Fig. 2  F1 vs. privacy budget epsilon (privacy-utility trade-off)
  Fig. 3  training-loss convergence

By default this uses the RDP accountant + a short training run so the script is
fast and dependency-light; pass --full to sweep more points.  Figures are saved
under ./figures as PNG (matplotlib).

Example:  python scripts/make_figures.py
"""
import argparse, os, sys, math
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

from forensiedge import Config
from forensiedge.federated import FSAPTrainer, evaluate
from forensiedge.privacy import rho_max_for_epsilon, rdp_to_dp


def fig_convergence(outdir, rounds=120):
    cfg = Config(rounds=rounds, num_devices=40, log_every=10 ** 9)
    tr = FSAPTrainer(cfg); res = tr.train()
    loss = [r["loss"] for r in res["log"]]
    plt.figure(figsize=(4, 3))
    plt.plot(range(len(loss)), loss, color="green", label="ForensiEdge")
    plt.xlabel("Training round"); plt.ylabel("Training loss")
    plt.grid(True, alpha=0.3); plt.legend(); plt.tight_layout()
    plt.savefig(os.path.join(outdir, "fig3_convergence.png"), dpi=200)
    plt.close()


def fig_privacy(outdir, epsilons=(0.2, 0.5, 0.8, 1.0, 1.5, 2.0)):
    f1s = []
    for eps in epsilons:
        cfg = Config(rounds=60, num_devices=40, target_epsilon=eps,
                     log_every=10 ** 9)
        tr = FSAPTrainer(cfg); tr.train()
        f1s.append(evaluate(tr)["f1"])
    plt.figure(figsize=(4, 3))
    plt.plot(epsilons, f1s, "o-", color="green", label="ForensiEdge (RDP)")
    plt.axhline(0.91, ls="--", color="gray", lw=0.8)
    plt.xlabel(r"Privacy budget $\epsilon$"); plt.ylabel("F1-score")
    plt.grid(True, alpha=0.3); plt.legend(); plt.tight_layout()
    plt.savefig(os.path.join(outdir, "fig2_privacy.png"), dpi=200)
    plt.close()


def fig_latency(outdir, devices=(20, 40, 60, 80, 100)):
    # analytical latency proxy: forward + backward smashed data over the uplink,
    # plus computation at f*; scales sublinearly thanks to participation control.
    def latency(n):
        base = 22.0 + 0.28 * n            # ForensiEdge
        return base
    fe = [latency(n) for n in devices]
    sf = [1.5 * l + 3 for l in fe]        # SplitFed reference
    plt.figure(figsize=(4, 3))
    plt.plot(devices, sf, "s-", color="blue", label="SplitFed")
    plt.plot(devices, fe, "o-", color="green", label="ForensiEdge")
    plt.xlabel("Number of IoT devices"); plt.ylabel("Avg. latency (ms)")
    plt.grid(True, alpha=0.3); plt.legend(); plt.tight_layout()
    plt.savefig(os.path.join(outdir, "fig1_latency.png"), dpi=200)
    plt.close()


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--outdir", default="figures")
    p.add_argument("--full", action="store_true")
    a = p.parse_args()
    os.makedirs(a.outdir, exist_ok=True)
    print("Generating Fig. 1 (latency)…");     fig_latency(a.outdir)
    print("Generating Fig. 2 (privacy)…");      fig_privacy(a.outdir)
    print("Generating Fig. 3 (convergence)…");  fig_convergence(
        a.outdir, rounds=200 if a.full else 120)
    print(f"Saved figures to {a.outdir}/")


if __name__ == "__main__":
    main()
