#!/usr/bin/env python3
"""Train ForensiEdge (FSAP) and report detection + forensic metrics.

Example:
    python scripts/train.py --rounds 200 --num-devices 100 --seed 0
    python scripts/train.py --dataset synthetic --target-epsilon 0.5
"""
import argparse, json, os, sys
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from forensiedge import Config
from forensiedge.federated import FSAPTrainer, evaluate


def parse_args() -> Config:
    p = argparse.ArgumentParser(description="Train ForensiEdge")
    cfg = Config()
    for name, val in vars(cfg).items():
        flag = "--" + name.replace("_", "-")
        if isinstance(val, bool):
            p.add_argument(flag, type=lambda s: s.lower() in ("1", "true", "yes"),
                           default=val)
        else:
            p.add_argument(flag, type=type(val), default=val)
    a = p.parse_args()
    return Config(**{k: getattr(a, k) for k in vars(cfg)})


def main():
    cfg = parse_args()
    print("Configuration:", json.dumps(vars(cfg), indent=2))
    trainer = FSAPTrainer(cfg)
    print(f"\nFEE parameters: {trainer.fee.num_parameters():,} "
          f"(~{trainer.fee.num_parameters()/1000:.0f}K -> "
          f"~{trainer.fee.num_parameters()/1000:.0f} KB at 8-bit)\n")
    result = trainer.train()
    metrics = evaluate(trainer)

    print("\n=== Privacy accounting ===")
    pv = result["privacy"]
    print(f"  rho_max               : {pv['rho_max']:.6f}")
    print(f"  sum_t rho_t (check)   : {pv['rho_total_check']:.6f}  (== rho_max)")
    print(f"  alpha*                : {pv['alpha_star']:.4f}")
    print(f"  epsilon (closed form) : {pv['epsilon_closed_form']:.4f}")

    print("\n=== Evaluation ===")
    for k, v in metrics.items():
        print(f"  {k:16s}: {v:.4f}" if isinstance(v, float) else f"  {k:16s}: {v}")

    os.makedirs("results", exist_ok=True)
    out = os.path.join("results", f"run_seed{cfg.seed}_eps{cfg.target_epsilon}.json")
    with open(out, "w") as f:
        json.dump({"config": vars(cfg), "metrics": metrics,
                   "privacy": {k: pv[k] for k in
                               ("rho_max", "rho_total_check", "alpha_star",
                                "epsilon_closed_form")}}, f, indent=2)
    print(f"\nSaved {out}")


if __name__ == "__main__":
    main()
