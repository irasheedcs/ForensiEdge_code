#!/usr/bin/env python3
"""Reproduce the Table I ablations and multi-seed confidence intervals.

Runs, over ``--seeds`` seeds:
  * ForensiEdge (full)         -- adaptive allocation + RDP
  * w/o adaptive allocation    -- uniform beta_t = 1/T
  * w/o RDP (naive DP)         -- no calibrated noise

Prints mean +/- 95% CI half-width for each metric.

Example:  python scripts/run_ablations.py --seeds 5 --rounds 200
"""
import argparse, os, sys, math, statistics
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from forensiedge import Config
from forensiedge.federated import FSAPTrainer, evaluate


VARIANTS = {
    "ForensiEdge (full)":     dict(adaptive_alloc=True,  use_rdp=True),
    "w/o adaptive alloc":     dict(adaptive_alloc=False, use_rdp=True),
    "w/o RDP (naive DP)":     dict(adaptive_alloc=True,  use_rdp=False),
}


def ci95(xs):
    if len(xs) < 2:
        return (statistics.mean(xs), 0.0)
    m = statistics.mean(xs); sd = statistics.stdev(xs)
    return m, 1.96 * sd / math.sqrt(len(xs))


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--seeds", type=int, default=5)
    p.add_argument("--rounds", type=int, default=200)
    p.add_argument("--num-devices", type=int, default=100)
    p.add_argument("--target-epsilon", type=float, default=1.0)
    p.add_argument("--dataset", type=str, default="synthetic")
    a = p.parse_args()

    print(f"{'Variant':22s} {'F1':>16s} {'EvidenceRecall':>18s} "
          f"{'EdgeRecall':>14s} {'SHD':>10s}")
    print("-" * 84)
    for name, overrides in VARIANTS.items():
        f1s, evr, edr, shd = [], [], [], []
        for s in range(a.seeds):
            cfg = Config(rounds=a.rounds, num_devices=a.num_devices,
                         target_epsilon=a.target_epsilon, dataset=a.dataset,
                         seed=s, log_every=10 ** 9, **overrides)
            tr = FSAPTrainer(cfg); tr.train()
            m = evaluate(tr)
            f1s.append(m["f1"]); evr.append(m["evidence_recall"])
            edr.append(m["edge_recall"]); shd.append(float(m["shd"]))
        mf, cf = ci95(f1s); me, ce = ci95(evr)
        md, cd = ci95(edr); ms, cs = ci95(shd)
        print(f"{name:22s} {mf:6.3f}+/-{cf:5.3f}   {me:6.3f}+/-{ce:5.3f}   "
              f"{md:6.3f}+/-{cd:5.3f}   {ms:5.1f}+/-{cs:4.1f}")


if __name__ == "__main__":
    main()
