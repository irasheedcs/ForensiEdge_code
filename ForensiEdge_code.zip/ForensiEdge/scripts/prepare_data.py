#!/usr/bin/env python3
"""Convert raw CIC-IoT-2023 / UNSW-NB15 CSVs into the ``.npz`` format that
``forensiedge.data.load_real_dataset`` expects.

This is a template: adjust ``FEATURE_COLS``, ``LABEL_COL``, and the attack-stage
mapping to your local copy of the data.  The output arrays are:
    x     (M, 1, L) float32   -- standardized feature windows
    y     (M,)      int64      -- 0 benign / 1 anomalous
    stage (M,)      int64      -- kill-chain stage id (-1 for benign)
    tau   (M,)      float64    -- timestamps (for causal ordering)

Usage:
    python scripts/prepare_data.py --csv path/to/CICIoT2023.csv \
        --name cic-iot-2023 --out ./data_files --seq-len 32
"""
import argparse, os
import numpy as np

# EDIT THESE for your dataset ------------------------------------------------
FEATURE_COLS = None          # e.g. ["flow_duration", "header_length", ...]; None = all numeric
LABEL_COL = "label"
TIME_COL = "timestamp"       # set None to synthesize monotone timestamps
# Map dataset attack-category strings -> kill-chain stage id (0..S-1).
STAGE_MAP = {
    "benign": -1,
    "recon": 0, "scanning": 0,
    "bruteforce": 1, "dos": 1,
    "exploitation": 2, "web": 2,
    "malware": 3, "infiltration": 3,
    "exfiltration": 4, "ddos": 4,
}
# ---------------------------------------------------------------------------


def to_stage(label: str) -> int:
    l = str(label).strip().lower()
    for key, s in STAGE_MAP.items():
        if key in l:
            return s
    return -1 if l in ("benign", "normal", "0") else 0


def main():
    import pandas as pd
    p = argparse.ArgumentParser()
    p.add_argument("--csv", required=True)
    p.add_argument("--name", required=True)
    p.add_argument("--out", default="./data_files")
    p.add_argument("--seq-len", type=int, default=32)
    a = p.parse_args()

    df = pd.read_csv(a.csv)
    cols = FEATURE_COLS or df.select_dtypes(include=[np.number]).columns.tolist()
    feats = df[cols].fillna(0).to_numpy(np.float32)
    feats = (feats - feats.mean(0)) / (feats.std(0) + 1e-6)

    # window features into length-L sequences (pad/truncate per row)
    L = a.seq_len
    M = feats.shape[0]
    x = np.zeros((M, 1, L), np.float32)
    for i in range(M):
        row = feats[i]
        x[i, 0, :min(L, row.size)] = row[:L]

    raw_label = df[LABEL_COL].to_numpy()
    stage = np.array([to_stage(v) for v in raw_label], np.int64)
    y = (stage >= 0).astype(np.int64)
    tau = (df[TIME_COL].to_numpy(np.float64) if TIME_COL in df.columns
           else np.arange(M, dtype=np.float64))

    os.makedirs(a.out, exist_ok=True)
    path = os.path.join(a.out, f"{a.name}.npz")
    np.savez_compressed(path, x=x, y=y, stage=stage, tau=tau)
    print(f"Wrote {path}  ({M} samples, {len(cols)} features)")


if __name__ == "__main__":
    main()
