"""Tests for the RDP accountant -- the correctness of the privacy analysis."""
import math
import os, sys
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from forensiedge.privacy import (
    per_round_rate, sigma_for_round, optimal_alpha, epsilon_of_alpha,
    rdp_to_dp, rho_max_for_epsilon, budget_weights, accountant_summary,
)


def test_budget_composes_to_rho_max():
    """sum_t rho_t must equal rho_max EXACTLY (fixes the rho_max/T bug)."""
    delta_s, rho_max = 2.0, 0.05
    etas = [1e-2 / math.sqrt(t + 1) for t in range(200)]
    betas = budget_weights(etas, adaptive=True)
    assert abs(sum(betas) - 1.0) < 1e-9
    sigmas = [sigma_for_round(delta_s, rho_max, b) for b in betas]
    total = sum(per_round_rate(delta_s, s) for s in sigmas)
    assert abs(total - rho_max) < 1e-9, total


def test_uniform_allocation_also_composes():
    delta_s, rho_max = 2.0, 0.1
    etas = [1.0] * 50
    betas = budget_weights(etas, adaptive=False)
    sigmas = [sigma_for_round(delta_s, rho_max, b) for b in betas]
    total = sum(per_round_rate(delta_s, s) for s in sigmas)
    assert abs(total - rho_max) < 1e-9


def test_theorem1_closed_form_matches_numeric_min():
    """eps* closed form == min_alpha eps(alpha)."""
    rho_max, delta = 0.05, 1e-5
    a_star = optimal_alpha(rho_max, delta)
    eps_star = rdp_to_dp(rho_max, delta)
    # scan alpha; closed form should be the minimum
    grid = [1.0 + 0.001 * k for k in range(1, 20000)]
    numeric = min(epsilon_of_alpha(rho_max, delta, a) for a in grid)
    assert abs(eps_star - epsilon_of_alpha(rho_max, delta, a_star)) < 1e-9
    assert eps_star <= numeric + 1e-6


def test_rho_max_inversion_roundtrips():
    delta = 1e-5
    for eps in (0.5, 1.0, 2.0):
        rho = rho_max_for_epsilon(eps, delta)
        assert abs(rdp_to_dp(rho, delta) - eps) < 1e-6


def test_adaptive_reduces_privacy_penalty():
    """sum_t eta_t^2 / beta_t is minimised by beta_t = eta_t / Gamma_T
    (Cauchy-Schwarz); adaptive should be <= uniform."""
    etas = [1e-2 / math.sqrt(t + 1) for t in range(200)]
    Gamma = sum(etas)
    adaptive = sum(e ** 2 / (e / Gamma) for e in etas)      # == Gamma^2
    uniform = sum(e ** 2 / (1.0 / len(etas)) for e in etas)  # == T * sum eta^2
    assert adaptive <= uniform + 1e-12
    assert abs(adaptive - Gamma ** 2) < 1e-9


if __name__ == "__main__":
    for name, fn in sorted(globals().items()):
        if name.startswith("test_") and callable(fn):
            fn(); print(f"PASS {name}")
    print("all tests passed")
