r"""Renyi Differential Privacy (RDP) accounting for the Forensic Split
Aggregation Protocol (FSAP).

This module implements the corrected privacy analysis of the paper:

Per-round Gaussian mechanism (Sec. III-C).  Releasing the smashed embedding
with sensitivity ``Delta_s`` under additive noise ``N(0, sigma_t^2 I)`` gives,
for every Renyi order ``alpha > 1``,

    (alpha,  alpha * rho_t)-RDP,   with   rho_t = Delta_s^2 / (2 sigma_t^2).      (per-round rate)

Budget-consistent adaptive allocation (Eq. 8-10).  We spread a fixed total
budget ``rho_max`` across rounds as ``rho_t = rho_max * beta_t`` with
``sum_t beta_t = 1``.  The resulting per-round noise is

    sigma_t^2 = Delta_s^2 / (2 * rho_max * beta_t).                               (Eq. 10)

Because RDP composes linearly, ``sum_t rho_t = rho_max`` *exactly* -- this fixes
the earlier version whose budgets summed to ``rho_max / T``.

Conversion to (eps, delta)-DP (Theorem 1).  Linear composition yields
``(alpha, alpha * rho_max)``-RDP, and the standard RDP->DP bound gives

    eps(alpha) = alpha * rho_max + ln(1/delta) / (alpha - 1),   alpha > 1.        (Eq. 9)

Minimising over the (order-dependent!) alpha gives the closed form

    alpha*  = 1 + sqrt( ln(1/delta) / rho_max ),
    eps*    = rho_max + 2 * sqrt( rho_max * ln(1/delta) ).                        (Eq. 13)
"""
from __future__ import annotations

import math
from typing import Sequence


def per_round_rate(delta_s: float, sigma: float) -> float:
    """RDP rate ``rho_t = Delta_s^2 / (2 sigma^2)`` of one Gaussian release."""
    if sigma <= 0:
        raise ValueError("sigma must be positive")
    return (delta_s ** 2) / (2.0 * sigma ** 2)


def sigma_for_round(delta_s: float, rho_max: float, beta_t: float) -> float:
    """Noise std for round ``t`` under allocation ``beta_t`` (Eq. 10)."""
    if not (0.0 < beta_t <= 1.0):
        raise ValueError("beta_t must lie in (0, 1]")
    var = (delta_s ** 2) / (2.0 * rho_max * beta_t)
    return math.sqrt(var)


def optimal_alpha(rho_max: float, delta: float) -> float:
    """alpha* minimising eps(alpha) (Theorem 1)."""
    return 1.0 + math.sqrt(math.log(1.0 / delta) / rho_max)


def epsilon_of_alpha(rho_max: float, delta: float, alpha: float) -> float:
    """eps(alpha) = alpha * rho_max + ln(1/delta)/(alpha-1)  (Eq. 9)."""
    if alpha <= 1.0:
        raise ValueError("alpha must be > 1")
    return alpha * rho_max + math.log(1.0 / delta) / (alpha - 1.0)


def rdp_to_dp(rho_max: float, delta: float) -> float:
    """Closed-form eps* = rho_max + 2*sqrt(rho_max ln(1/delta))  (Eq. 13)."""
    return rho_max + 2.0 * math.sqrt(rho_max * math.log(1.0 / delta))


def rho_max_for_epsilon(target_epsilon: float, delta: float) -> float:
    """Invert eps* to find the total RDP budget rho_max that attains
    ``target_epsilon`` at ``delta``.

    Solving  rho + 2*sqrt(rho*L) - eps = 0  with ``L = ln(1/delta)`` and
    ``u = sqrt(rho)`` gives ``u = -sqrt(L) + sqrt(L + eps)`` (positive root).
    """
    L = math.log(1.0 / delta)
    u = -math.sqrt(L) + math.sqrt(L + target_epsilon)
    return u * u


def budget_weights(etas: Sequence[float], adaptive: bool = True) -> list[float]:
    """Per-round budget weights ``beta_t`` with ``sum_t beta_t = 1``.

    Adaptive (paper):   beta_t = eta_t / Gamma_T,   Gamma_T = sum_t eta_t.
    Uniform (ablation): beta_t = 1 / T.
    """
    T = len(etas)
    if adaptive:
        Gamma_T = float(sum(etas))
        return [e / Gamma_T for e in etas]
    return [1.0 / T for _ in range(T)]


def accountant_summary(delta_s: float, rho_max: float, delta: float,
                       etas: Sequence[float], adaptive: bool = True) -> dict:
    """Return a dictionary summarising the end-to-end guarantee, and verify
    that the per-round budgets compose back to ``rho_max``."""
    betas = budget_weights(etas, adaptive)
    sigmas = [sigma_for_round(delta_s, rho_max, b) for b in betas]
    rhos = [per_round_rate(delta_s, s) for s in sigmas]
    alpha = optimal_alpha(rho_max, delta)
    return {
        "rho_max": rho_max,
        "rho_total_check": sum(rhos),      # must equal rho_max
        "alpha_star": alpha,
        "epsilon_closed_form": rdp_to_dp(rho_max, delta),
        "epsilon_at_alpha_star": epsilon_of_alpha(rho_max, delta, alpha),
        "sigma_min": min(sigmas),
        "sigma_max": max(sigmas),
        "betas": betas,
        "sigmas": sigmas,
    }
