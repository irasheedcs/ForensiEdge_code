r"""Forensic Split Aggregation Protocol (FSAP) -- the end-to-end trainer.

One round (Algorithm 1):
  1. controller sets per-round noise sigma_t from the RDP allocation (Eq. 10);
  2. selected devices run the FEE forward pass, clip + Gaussian-perturb the
     smashed embedding (Eq. 7), and upload it with labels;
  3. the edge/cloud computes the forensic loss (CE + contrastive, Eq. 12),
     backpropagates, and returns gradients to the devices;
  4. devices update the FEE; the server updates the classifier/CFGN;
  5. Lyapunov queues advance (Eqs. 14-15).

The privacy guarantee is enforced by the RDP accountant; ``use_rdp=False``
disables calibrated noise (the naive-DP ablation) and ``adaptive_alloc=False``
switches to uniform allocation.
"""
from __future__ import annotations

import math
from typing import List, Dict

import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F

from ..config import Config
from ..models import ForensicEvidenceEncoder, CFGN, sensitivity_bound
from ..optim import LyapunovController, optimal_frequency
from ..privacy import (
    rho_max_for_epsilon, budget_weights, sigma_for_round, accountant_summary,
)
from ..data import get_dataset, build_federation


def contrastive_term(z: torch.Tensor, y: torch.Tensor, temp: float = 0.5) -> torch.Tensor:
    """Simple supervised contrastive regulariser on the embeddings."""
    if z.size(0) < 2:
        return z.new_tensor(0.0)
    zc = F.normalize(z, dim=-1)
    sim = zc @ zc.t() / temp
    sim.fill_diagonal_(float("-inf"))
    logp = F.log_softmax(sim, dim=1)
    # diagonal is -inf after masking; zero it so the later 0*(-inf) is avoided
    logp = torch.nan_to_num(logp, neginf=0.0)
    same = (y.unsqueeze(1) == y.unsqueeze(0)).float()
    same.fill_diagonal_(0)
    denom = same.sum(1).clamp_min(1.0)
    return -(same * logp).sum(1).div(denom).mean()


class FSAPTrainer:
    def __init__(self, cfg: Config):
        self.cfg = cfg
        torch.manual_seed(cfg.seed)
        np.random.seed(cfg.seed)
        self.device = torch.device(cfg.device)

        # data + federation
        data = get_dataset(cfg)
        self.shards = build_federation(data, cfg.num_devices, cfg.dirichlet_alpha,
                                       cfg.train_frac, cfg.seed)

        # models: one shared FEE (device-side) + server-side CFGN
        self.fee = ForensicEvidenceEncoder(
            cfg.in_channels, cfg.seq_len, cfg.conv_channels, cfg.hidden_dim,
            cfg.embed_dim, cfg.num_classes, cfg.groupnorm_groups, cfg.clip_C
        ).to(self.device)
        self.cfgn = CFGN(cfg.embed_dim, cfg.hidden_dim, cfg.gat_layers,
                         cfg.gat_heads, cfg.tau_c).to(self.device)

        # privacy accounting
        self.delta_s = sensitivity_bound(cfg.clip_C)
        self.rho_max = rho_max_for_epsilon(cfg.target_epsilon, cfg.delta)
        etas = [cfg.eta0 / math.sqrt(t + 1) for t in range(cfg.rounds)]
        self.etas = etas
        self.betas = budget_weights(etas, cfg.adaptive_alloc)

        # Lyapunov controller.  Warm-start the utility-deficit queue near its
        # steady-state value (~V * marginal_cost / utility) so the participation
        # rule is active from the first round instead of after an O(V) warm-up.
        self.ctrl = LyapunovController(
            num_devices=cfg.num_devices, V=cfg.V, U_min=cfg.participation_min,
            rho_bar=self.rho_max / cfg.rounds,
        )
        self._f_star = optimal_frequency(cfg.omega1, cfg.omega2, cfg.kappa, cfg.freq_max)
        self._comp_c = (self._f_star / cfg.freq_max) ** 2 * 1e-3
        self._comm_c = 1e-3
        self._priv_c = self.rho_max / cfg.rounds
        self._mean_util = 0.75
        # Aggregate per-round utility floor: target ``participation_min`` fraction
        # of devices active (keeps queue dynamics balanced around that rate).
        self.ctrl.U_min = cfg.participation_min * cfg.num_devices * self._mean_util
        self.ctrl.min_participants = cfg.participation_min * cfg.num_devices
        mean_cost = (cfg.omega1 * self._comp_c + cfg.omega2 * self._comm_c
                     + cfg.omega3 * self._priv_c)
        self.ctrl.Q = 1.1 * cfg.V * mean_cost / self._mean_util
        self.log: List[Dict] = []

    # ------------------------------------------------------------------ #
    def _round_sigma(self, t: int) -> float:
        if not self.cfg.use_rdp:
            return 0.0
        return sigma_for_round(self.delta_s, self.rho_max, self.betas[t])

    def _device_batch(self, shard, rng):
        tr = shard[0]
        if len(tr) == 0:
            return None
        n = min(self.cfg.batch_size, len(tr))
        idx = rng.choice(len(tr), size=n, replace=False)
        x = torch.tensor(tr.x[idx], device=self.device)
        y = torch.tensor(tr.y[idx], device=self.device)
        tau = tr.tau[idx]                       # numpy (for causal ordering)
        stg = tr.stage[idx]                     # numpy attack-stage ids
        inc = tr.incident[idx]                  # numpy incident ids
        return x, y, tau, stg, inc

    def _train_cfgn(self, emb_buf, tau_buf, stg_buf, inc_buf, opt_srv):
        """One supervised edge-prediction step for the CFGN using the batch's
        attack-stage annotations as causal ground truth (Eq. 6 graph + BCE)."""
        from ..metrics import build_stage_ground_truth
        if not emb_buf:
            return
        z = torch.cat(emb_buf, 0)
        tau = np.concatenate(tau_buf)
        stg = np.concatenate(stg_buf)
        inc = np.concatenate(inc_buf)
        # causal edges exist only among attack-stage events; focus training there
        attack = np.where(stg >= 0)[0]
        if len(attack) < 2:
            return
        attack = attack[np.argsort(tau[attack])]
        order = attack[:min(200, len(attack))]
        z = z[order]
        tau_t = torch.tensor(tau[order], device=self.device, dtype=torch.float32)
        gt = build_stage_ground_truth(stg[order], tau[order], inc[order])
        if gt.sum() == 0:
            return
        gt_t = torch.tensor(gt, device=self.device, dtype=torch.float32)
        _, edge_logits = self.cfgn(z, tau_t)
        temporal = torch.tensor(
            (tau[order][:, None] < tau[order][None, :]), device=self.device)
        valid = temporal & ~torch.isinf(edge_logits)
        if valid.sum() == 0:
            return
        # class-balanced BCE (positives are rare)
        pos_weight = (valid.sum() - gt_t[valid].sum()) / gt_t[valid].sum().clamp_min(1.0)
        loss = F.binary_cross_entropy_with_logits(
            edge_logits[valid], gt_t[valid], pos_weight=pos_weight)
        opt_srv.zero_grad(); loss.backward(); opt_srv.step()

    def train(self) -> Dict:
        cfg = self.cfg
        # Adam device optimiser driven by the eta_t = eta_0/sqrt(t) schedule
        # (the same schedule defines the adaptive privacy weights beta_t).
        opt_fee = torch.optim.Adam(self.fee.parameters(), lr=cfg.eta0)
        opt_srv = torch.optim.Adam(self.cfgn.parameters(), lr=1e-3)
        rng = np.random.default_rng(cfg.seed)

        for t in range(cfg.rounds):
            eta_t = self.etas[t]
            # Adam base lr follows the schedule but is floored so late rounds
            # still make progress (the raw 1/sqrt(t) decay would stall Adam).
            for g in opt_fee.param_groups:
                g["lr"] = max(eta_t, 1e-3)
            sigma_t = self._round_sigma(t)

            # ---- per-device utility / cost estimates for the controller ---
            utilities = [rng.uniform(0.5, 1.0) for _ in range(cfg.num_devices)]
            comp_c = [self._comp_c] * cfg.num_devices
            comm_c = [self._comm_c] * cfg.num_devices
            priv_c = [self._priv_c] * cfg.num_devices
            gamma = self.ctrl.participation(utilities, comp_c, comm_c, priv_c,
                                            cfg.omega1, cfg.omega2, cfg.omega3)

            # ---- selected devices do a split-learning step ----------------
            # FedSGD-style: each participating device contributes its local loss;
            # gradients are AVERAGED across devices (weighted by |D_n|) and applied
            # in a single server step, so the update scale is independent of how
            # many devices participate.
            round_loss, n_used = 0.0, 0
            emb_buf, tau_buf, stg_buf, inc_buf = [], [], [], []
            active = [n for n, g in enumerate(gamma) if g >= 0.5]

            # Each participating device performs ``local_steps`` local steps;
            # gradients are averaged across devices at every step (FedSGD).
            for step in range(cfg.local_steps):
                opt_fee.zero_grad()
                device_losses = []
                for n in active:
                    batch = self._device_batch(self.shards[n], rng)
                    if batch is None:
                        continue
                    x, y, tau, stg, inc = batch
                    z, logits = self.fee(x)                 # clean FEE forward
                    ce = F.cross_entropy(logits, y)         # local task (no privacy cost)
                    # released smashed data is privatized (Eq. 7)
                    z_rel = z + torch.randn_like(z) * sigma_t if sigma_t > 0 else z
                    con = contrastive_term(z_rel, y)
                    loss = cfg.lambda1 * ce + cfg.lambda2 * con
                    if torch.isfinite(loss):
                        device_losses.append(loss)
                        if step == cfg.local_steps - 1:     # buffer last-step embeddings
                            emb_buf.append(z_rel.detach())
                            tau_buf.append(tau); stg_buf.append(stg); inc_buf.append(inc)
                if device_losses:
                    mean_loss = torch.stack(device_losses).mean()
                    mean_loss.backward()
                    torch.nn.utils.clip_grad_norm_(self.fee.parameters(), max_norm=5.0)
                    opt_fee.step()
                    round_loss = float(mean_loss.detach()); n_used = len(device_losses)

            # ---- server-side CFGN edge-supervision step -------------------
            self._train_cfgn(emb_buf, tau_buf, stg_buf, inc_buf, opt_srv)

            served = [gamma[n] for n in range(cfg.num_devices)]
            self.ctrl.update(served, utilities, self.rho_max / cfg.rounds)

            avg_loss = round_loss                      # already device-averaged
            self.log.append({"round": t, "loss": avg_loss, "sigma": sigma_t,
                             "eta": eta_t, "participation": sum(gamma) / cfg.num_devices})
            if cfg.log_every <= cfg.rounds and (t % cfg.log_every == 0 or t == cfg.rounds - 1):
                print(f"[round {t:3d}] loss={avg_loss:.4f}  sigma_t={sigma_t:.4f}  "
                      f"part={sum(gamma)/cfg.num_devices:.2f}  Q={self.ctrl.Q:.3f}")

        return {
            "log": self.log,
            "privacy": accountant_summary(self.delta_s, self.rho_max, cfg.delta,
                                          self.etas, cfg.adaptive_alloc),
            "fee_params": self.fee.num_parameters(),
        }
