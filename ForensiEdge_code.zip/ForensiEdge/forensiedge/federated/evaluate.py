r"""Evaluation: detection metrics + forensic-graph reconstruction metrics."""
from __future__ import annotations

from typing import Dict
import numpy as np
import torch

from ..metrics import (
    prf1, evidence_recall, causal_edge_recall, structural_hamming_distance,
    build_stage_ground_truth,
)
from ..models import extract_timeline


@torch.no_grad()
def evaluate(trainer) -> Dict:
    cfg = trainer.cfg
    fee, cfgn, device = trainer.fee, trainer.cfgn, trainer.device
    fee.eval(); cfgn.eval()

    # ---- pooled test set across devices ---------------------------------
    xs, ys, stages, taus, incs = [], [], [], [], []
    for tr, te in trainer.shards:
        if len(te) == 0:
            continue
        xs.append(te.x); ys.append(te.y); stages.append(te.stage)
        taus.append(te.tau); incs.append(te.incident)
    x = torch.tensor(np.concatenate(xs), device=device)
    y = np.concatenate(ys); stage = np.concatenate(stages)
    tau = np.concatenate(taus); incident = np.concatenate(incs)

    # ---- detection ------------------------------------------------------
    z, logits = fee(x)
    y_pred = logits.argmax(1).cpu().numpy()
    det = prf1(y, y_pred)

    # stage attribution: nearest-stage-centroid on embeddings (proxy)
    z_np = z.cpu().numpy()
    correct_stage = _stage_attribution_correct(z_np, stage)
    ev_rec = evidence_recall(stage, y_pred, correct_stage)

    # ---- forensic graph over ATTACK-STAGE events (dense N^2) ------------
    # Causal kill-chains live among attack events; benign windows (stage -1)
    # carry no causal edges, so we restrict the graph to stage>=0 events.
    attack = np.where(stage >= 0)[0]
    attack = attack[np.argsort(tau[attack])]
    order = attack[:min(300, len(attack))]
    zt = torch.tensor(z_np[order], device=device)
    if len(order) < 2:
        return {"precision": det["precision"], "recall": det["recall"],
                "f1": det["f1"], "evidence_recall": ev_rec,
                "edge_recall": 0.0, "shd": 0, "n_test": int(len(y))}
    tt = torch.tensor(tau[order], device=device, dtype=torch.float32)
    _, edge_logits = cfgn(zt, tt)
    prob = torch.sigmoid(edge_logits).cpu().numpy()
    prob = np.nan_to_num(prob, nan=0.0)

    true_adj = build_stage_ground_truth(stage[order], tau[order], incident[order])
    temporal = (tau[order][:, None] < tau[order][None, :])
    # predict edges at the same sparsity as the ground truth (fair recovery eval)
    n_true = int(true_adj.sum())
    pred_adj = np.zeros_like(true_adj)
    if n_true > 0:
        cand = np.argwhere(temporal)
        scores = prob[temporal]
        keep = cand[np.argsort(-scores)[:n_true]]
        pred_adj[keep[:, 0], keep[:, 1]] = 1
    edge_rec = causal_edge_recall(pred_adj, true_adj)
    shd = structural_hamming_distance(pred_adj, true_adj)

    return {
        "precision": det["precision"], "recall": det["recall"], "f1": det["f1"],
        "evidence_recall": ev_rec, "edge_recall": edge_rec, "shd": shd,
        "n_test": int(len(y)),
    }


def _stage_attribution_correct(z: np.ndarray, stage: np.ndarray) -> np.ndarray:
    """Assign each event to the nearest stage centroid; return a correctness mask."""
    valid = stage >= 0
    correct = np.zeros(len(stage), dtype=bool)
    if valid.sum() == 0:
        return correct
    stages = np.unique(stage[valid])
    centroids = {s: z[(stage == s)].mean(0) for s in stages}
    C = np.stack([centroids[s] for s in stages])
    for i in np.where(valid)[0]:
        d = np.linalg.norm(C - z[i], axis=1)
        correct[i] = (stages[int(np.argmin(d))] == stage[i])
    return correct
