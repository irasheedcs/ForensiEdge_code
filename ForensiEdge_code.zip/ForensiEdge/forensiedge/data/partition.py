r"""Non-IID partitioning across devices via a Dirichlet(alpha) prior, plus a
per-device train/test split.
"""
from __future__ import annotations

from typing import List, Tuple
import numpy as np

from .datasets import ForensicWindows


def dirichlet_partition(labels: np.ndarray, num_devices: int, alpha: float,
                        rng: np.random.Generator) -> List[np.ndarray]:
    """Split indices among devices so each device's class mix ~ Dirichlet(alpha).

    Small ``alpha`` -> highly non-IID; large ``alpha`` -> near-IID.
    """
    classes = np.unique(labels)
    device_idx: List[List[int]] = [[] for _ in range(num_devices)]
    for c in classes:
        idx_c = np.where(labels == c)[0]
        rng.shuffle(idx_c)
        props = rng.dirichlet(alpha * np.ones(num_devices))
        cuts = (np.cumsum(props) * len(idx_c)).astype(int)[:-1]
        for d, chunk in enumerate(np.split(idx_c, cuts)):
            device_idx[d].extend(chunk.tolist())
    return [np.array(sorted(ix), dtype=np.int64) for ix in device_idx]


def train_test_split_device(idx: np.ndarray, train_frac: float,
                            rng: np.random.Generator) -> Tuple[np.ndarray, np.ndarray]:
    idx = idx.copy()
    rng.shuffle(idx)
    k = int(len(idx) * train_frac)
    return idx[:k], idx[idx.size and k:]


def build_federation(data: ForensicWindows, num_devices: int, alpha: float,
                     train_frac: float, seed: int):
    """Return per-device (train, test) ForensicWindows shards."""
    rng = np.random.default_rng(seed + 12345)
    parts = dirichlet_partition(data.y, num_devices, alpha, rng)
    shards = []
    for ix in parts:
        if len(ix) == 0:
            shards.append((data.subset(ix), data.subset(ix)))
            continue
        tr, te = train_test_split_device(ix, train_frac, rng)
        shards.append((data.subset(tr), data.subset(te)))
    return shards
