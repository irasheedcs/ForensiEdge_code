r"""Datasets for ForensiEdge.

The paper evaluates on CIC-IoT-2023 and UNSW-NB15.  Those archives are large and
license-gated, so this repository ships a faithful **synthetic multi-stage
attack generator** that runs out of the box and, crucially, provides the
*attack-stage annotations* needed to build causal ground-truth graphs
(kill-chain identifiers + temporal order).  Loaders for the real datasets are
provided with a documented, drop-in interface.

Each sample is a traffic window ``x`` of shape ``(1, seq_len)`` with:
  * ``y``      : binary label (benign / anomalous),
  * ``stage``  : attack-stage id in ``{-1, 0, 1, ..., S-1}`` (-1 = benign),
  * ``tau``    : timestamp (monotone within an incident) for causal ordering.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Optional, Tuple
import numpy as np


@dataclass
class ForensicWindows:
    x: np.ndarray        # (M, 1, L) float32
    y: np.ndarray        # (M,) int64  {0,1}
    stage: np.ndarray    # (M,) int64  {-1, 0..S-1}
    tau: np.ndarray      # (M,) float64 timestamps
    incident: np.ndarray # (M,) int64  incident id (-1 for benign)

    def __len__(self) -> int:
        return len(self.y)

    def subset(self, idx) -> "ForensicWindows":
        return ForensicWindows(self.x[idx], self.y[idx], self.stage[idx],
                               self.tau[idx], self.incident[idx])


def make_synthetic(num_samples: int, seq_len: int = 32, num_stages: int = 5,
                   benign_frac: float = 0.5, rng: Optional[np.random.Generator] = None
                   ) -> ForensicWindows:
    """Generate benign traffic and multi-stage attack incidents.

    Attack stages form a kill chain (stage 0 -> 1 -> ... -> S-1); each stage
    has a distinct spectral signature so that (a) windows are separable and
    (b) later stages causally follow earlier ones in time.
    """
    rng = rng or np.random.default_rng()
    xs, ys, stages, taus, incs = [], [], [], [], []
    t = 0.0

    n_benign = int(num_samples * benign_frac)
    n_attack = num_samples - n_benign

    # --- benign: low-amplitude pink-ish noise -----------------------------
    for _ in range(n_benign):
        base = rng.normal(0, 0.3, size=seq_len)
        drift = 0.2 * np.sin(np.linspace(0, rng.uniform(1, 3) * np.pi, seq_len))
        xs.append((base + drift).astype(np.float32))
        ys.append(0); stages.append(-1); incs.append(-1)
        t += rng.exponential(1.0); taus.append(t)

    # --- attacks: grouped into incidents, each a full kill chain ----------
    per_incident = num_stages
    n_incidents = max(1, n_attack // per_incident)
    for inc in range(n_incidents):
        t += rng.exponential(3.0)              # gap before an incident
        # per-incident shared signature (e.g., common source/campaign), so that
        # events of the same incident are linkable into a causal chain
        inc_sig = rng.normal(0, 0.8, size=seq_len)
        inc_phase = rng.uniform(0, 2 * np.pi)
        for s in range(num_stages):
            freq = 1.0 + 1.5 * s               # stage-specific frequency
            amp = 0.8 + 0.15 * s
            sig = amp * np.sin(np.linspace(inc_phase, inc_phase + freq * 2 * np.pi, seq_len))
            sig = sig + 0.8 * inc_sig + rng.normal(0, 0.2, size=seq_len)
            xs.append(sig.astype(np.float32))
            ys.append(1); stages.append(s); incs.append(inc)
            t += rng.uniform(0.5, 1.5)         # stages advance in time
            taus.append(t)

    x = np.stack(xs)[:, None, :]               # (M, 1, L)
    y = np.array(ys, dtype=np.int64)
    stage = np.array(stages, dtype=np.int64)
    tau = np.array(taus, dtype=np.float64)
    incident = np.array(incs, dtype=np.int64)

    perm = rng.permutation(len(y))             # shuffle (tau still recoverable)
    return ForensicWindows(x[perm], y[perm], stage[perm], tau[perm], incident[perm])


def load_real_dataset(name: str, root: str, seq_len: int = 32) -> ForensicWindows:
    """Drop-in loader for CIC-IoT-2023 / UNSW-NB15.

    Expects a preprocessed ``.npz`` at ``{root}/{name}.npz`` with arrays
    ``x (M,1,L) float32``, ``y (M,) int64``, ``stage (M,) int64``,
    ``tau (M,) float64``.  See ``scripts/prepare_data.py`` for the conversion
    recipe from the raw CSVs (feature windowing + attack-stage annotation).
    """
    import os
    path = os.path.join(root, f"{name}.npz")
    if not os.path.exists(path):
        raise FileNotFoundError(
            f"{path} not found. Download the dataset and run "
            f"scripts/prepare_data.py to produce it, or use --dataset synthetic."
        )
    d = np.load(path)
    inc = (d["incident"].astype(np.int64) if "incident" in d
           else np.full(len(d["y"]), -1, dtype=np.int64))
    return ForensicWindows(d["x"].astype(np.float32), d["y"].astype(np.int64),
                           d["stage"].astype(np.int64), d["tau"].astype(np.float64), inc)


def get_dataset(cfg) -> ForensicWindows:
    rng = np.random.default_rng(cfg.seed)
    if cfg.dataset == "synthetic":
        total = cfg.samples_per_device * cfg.num_devices
        return make_synthetic(total, cfg.seq_len, cfg.num_attack_stages, rng=rng)
    return load_real_dataset(cfg.dataset, cfg.data_root, cfg.seq_len)
