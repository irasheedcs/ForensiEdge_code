"""ForensiEdge: Privacy-Preserving Federated Split Learning for Network
Forensics in Edge-Intelligent 6G-IoT."""
from .config import Config

__version__ = "1.0.0"
__all__ = ["Config"]
