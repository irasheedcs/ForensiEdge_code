"""Central configuration for ForensiEdge.

All defaults match the values reported in the paper (Sec. IV, "Setup").
Override any field from the CLI, e.g.  ``python scripts/train.py --rounds 50``.
"""
from __future__ import annotations

from dataclasses import dataclass, field, asdict
from typing import Tuple
import json


@dataclass
class Config:
    # ---- Federation topology --------------------------------------------
    num_devices: int = 100          # N  TinyML IoT devices
    num_edge_servers: int = 5       # M  edge servers
    rounds: int = 200               # T  communication rounds
    participation_min: float = 0.30 # U_min feasibility floor for Lyapunov (Eq. 4)

    # ---- Model ----------------------------------------------------------
    in_channels: int = 1            # univariate traffic feature stream
    seq_len: int = 32               # length of each traffic window
    conv_channels: int = 16         # depthwise-separable conv width
    hidden_dim: int = 64            # bottleneck hidden width
    embed_dim: int = 64             # d_z  smashed-embedding dimension
    num_classes: int = 2            # benign / anomalous (per-window head)
    groupnorm_groups: int = 4       # GroupNorm groups (per-sample, data-independent)

    # ---- CFGN (Causal Forensic Graph Network) ---------------------------
    gat_layers: int = 2             # L  graph-attention layers
    gat_heads: int = 4              # attention heads per layer
    tau_c: float = 0.1              # temperature in temporally-constrained attention (Eq. 6)

    # ---- Optimisation / SGD ---------------------------------------------
    eta0: float = 1e-2              # base step size  eta_0  (schedule eta_t = eta_0/sqrt(t))
    local_steps: int = 3            # E  local SGD steps per device per round
    batch_size: int = 32            # B_n
    lambda1: float = 1.0            # cross-entropy weight in forensic loss (Eq. 12)
    lambda2: float = 0.1            # contrastive weight in forensic loss (Eq. 12)

    # ---- Differential privacy (RDP) -------------------------------------
    clip_C: float = 1.0             # embedding clip norm  =>  Delta_s = 2C
    delta: float = 1e-5            # target delta in (eps, delta)-DP
    target_epsilon: float = 1.0     # default privacy level used to derive rho_max
    adaptive_alloc: bool = True     # beta_t = eta_t / Gamma_T  (False => uniform 1/T)
    use_rdp: bool = True            # False => no calibrated noise (naive-DP ablation)

    # ---- Lyapunov drift-plus-penalty ------------------------------------
    V: float = 1e4                  # Lyapunov control parameter (cost vs. backlog)
    omega1: float = 1.0             # latency weight in system cost (P1)
    omega2: float = 1.0             # energy weight in system cost (P1)
    omega3: float = 1.0             # privacy weight in system cost (P1)
    kappa: float = 1e-27            # effective switched-capacitance (energy model)
    freq_max: float = 2.0e9         # f_n^max  device CPU frequency ceiling (Hz)

    # ---- Data -----------------------------------------------------------
    dataset: str = "synthetic"      # {synthetic, cic-iot-2023, unsw-nb15}
    data_root: str = "./data_files"
    train_frac: float = 0.70        # 70/30 split
    dirichlet_alpha: float = 0.5    # non-IID Dirichlet concentration
    samples_per_device: int = 256   # synthetic samples/device
    num_attack_stages: int = 5      # multi-stage kill-chain depth (for causal GT)

    # ---- Runtime --------------------------------------------------------
    seed: int = 0
    device: str = "cpu"             # {cpu, cuda}
    log_every: int = 20

    def to_json(self, path: str) -> None:
        with open(path, "w") as f:
            json.dump(asdict(self), f, indent=2)

    @classmethod
    def from_json(cls, path: str) -> "Config":
        with open(path) as f:
            return cls(**json.load(f))
