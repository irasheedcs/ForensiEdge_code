r"""Lyapunov drift-plus-penalty online optimisation (Sec. III-D).

We maintain two virtual queues:
  * a utility-deficit queue ``Q`` enforcing the participation floor U_min (Eq. 4),
  * a privacy-budget queue ``Z`` enforcing the RDP cap (Eq. 5).

Each round the controller minimises ``drift + V * cost`` per device, which
decouples into:
  * a participation rule (Eq. 16): device n participates iff its marginal
    utility outweighs its marginal system cost;
  * a closed-form CPU-frequency rule (Eq. 17)

        f_n* = min( f_n^max,  cbrt( omega1 / (2 * omega2 * kappa_n) ) ),

    where the denominator is 2 (not 3) -- the corrected optimiser.
"""
from __future__ import annotations

import math
from dataclasses import dataclass, field
from typing import List


def optimal_frequency(omega1: float, omega2: float, kappa: float,
                      freq_max: float) -> float:
    """Closed-form device frequency of Eq. (17)."""
    f_unconstrained = (omega1 / (2.0 * omega2 * kappa)) ** (1.0 / 3.0)
    return min(freq_max, f_unconstrained)


@dataclass
class LyapunovController:
    num_devices: int
    V: float = 1e4
    U_min: float = 0.30
    rho_bar: float = 0.0            # per-round privacy target = rho_max / T
    min_participants: float = 1.0   # participation floor (# devices) per round
    Q: float = 0.0                  # utility-deficit backlog
    Z: float = 0.0                  # privacy backlog
    history: List[dict] = field(default_factory=list)

    def participation(self, utilities, comp_costs, comm_costs, priv_costs,
                      omega1: float, omega2: float, omega3: float):
        """Return a 0/1 participation vector for the current round (Eq. 16).

        Device n participates when the Lyapunov-weighted utility exceeds the
        weighted marginal system cost:
            Q * U(e_n)  -  Z * rho_n  >  V * c_n
        with c_n = omega1*D_comp + omega2*E + omega3*L_priv.
        """
        gamma = []
        margins = []
        for u, dc, mc, pc in zip(utilities, comp_costs, comm_costs, priv_costs):
            weighted_cost = self.V * (omega1 * dc + omega2 * mc + omega3 * pc)
            lhs = self.Q * u - self.Z * pc
            margins.append(lhs - weighted_cost)
            gamma.append(1.0 if lhs > weighted_cost else 0.0)

        # Guarantee the minimum-participation constraint (Eq. 4): if fewer than
        # ``U_min``-worth of devices cleared the rule, admit the next-best ones
        # by Lyapunov margin so no round is left with zero participation.
        floor = int(math.ceil(self.min_participants))
        if sum(gamma) < floor:
            order = sorted(range(len(margins)), key=lambda i: margins[i], reverse=True)
            for i in order:
                if sum(gamma) >= floor:
                    break
                gamma[i] = 1.0
        return gamma

    def update(self, gamma, utilities, rho_round):
        """Advance the virtual queues (Eqs. 14-15).

        Q(t+1) = max{ Q + U_min - sum_n gamma_n U(e_n), 0 }
        Z(t+1) = max{ Z + sum_n gamma_n rho_n - rho_bar, 0 }
        """
        served_utility = sum(g * u for g, u in zip(gamma, utilities))
        spent_privacy = sum(g * rho_round for g in gamma)
        self.Q = max(self.Q + self.U_min - served_utility, 0.0)
        self.Z = max(self.Z + spent_privacy - self.rho_bar, 0.0)
        self.history.append({
            "Q": self.Q, "Z": self.Z,
            "served_utility": served_utility,
            "participation_rate": sum(gamma) / max(len(gamma), 1),
        })
        return self.Q, self.Z


def energy_cost(freq: float, comm_bits: float, rate: float, tx_power: float,
                kappa: float, fee_cycles: float, batch: int) -> float:
    """Per-round device energy E_n (Eq. 2): computation + communication."""
    e_comp = kappa * (freq ** 2) * fee_cycles * batch
    e_comm = tx_power * (comm_bits / max(rate, 1e-9))
    return e_comp + e_comm
