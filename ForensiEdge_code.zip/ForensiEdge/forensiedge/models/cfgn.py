r"""Causal Forensic Graph Network (CFGN) -- the cloud-side model.

Given per-event embeddings ``z_i`` with timestamps ``tau_i``, CFGN builds a
dynamic causal graph with temporally-constrained attention (Eq. 6):

    w_ij = softmax_j( sim(z_i, z_j) / tau_c ) * 1[tau_i < tau_j],

then refines node representations with an ``L``-layer graph attention network
(GAT) and reconstructs incident timelines by maximum-weight
directed-acyclic-subgraph extraction.

The GAT layer is implemented natively (no torch-geometric dependency) so the
repository is self-contained.
"""
from __future__ import annotations

import torch
import torch.nn as nn
import torch.nn.functional as F


def temporal_causal_adjacency(z: torch.Tensor, tau: torch.Tensor,
                              tau_c: float = 0.1) -> torch.Tensor:
    """Return the row-stochastic causal weight matrix ``w`` of Eq. (6).

    z:   (Nnodes, d)      event embeddings
    tau: (Nnodes,)        event timestamps
    """
    sim = (z @ z.t()) / tau_c                       # cosine-like similarity / temperature
    # temporal mask: edge i->j only if tau_i < tau_j (cause precedes effect)
    mask = (tau.unsqueeze(1) < tau.unsqueeze(0))    # (N, N) boolean
    sim = sim.masked_fill(~mask, float("-inf"))
    w = torch.softmax(sim, dim=1)
    # rows that are fully masked (latest events) become all-zero instead of NaN
    w = torch.nan_to_num(w, nan=0.0)
    return w


class GATLayer(nn.Module):
    """Multi-head graph-attention layer (Velickovic et al., 2018), dense form."""

    def __init__(self, in_dim: int, out_dim: int, heads: int = 4,
                 dropout: float = 0.0, concat: bool = True):
        super().__init__()
        self.heads = heads
        self.out_dim = out_dim
        self.concat = concat
        self.W = nn.Linear(in_dim, heads * out_dim, bias=False)
        self.a_src = nn.Parameter(torch.empty(heads, out_dim))
        self.a_dst = nn.Parameter(torch.empty(heads, out_dim))
        self.leaky = nn.LeakyReLU(0.2)
        self.dropout = nn.Dropout(dropout)
        nn.init.xavier_uniform_(self.W.weight)
        nn.init.xavier_uniform_(self.a_src)
        nn.init.xavier_uniform_(self.a_dst)

    def forward(self, x: torch.Tensor, adj_mask: torch.Tensor) -> torch.Tensor:
        # x: (N, in_dim); adj_mask: (N, N) boolean of allowed edges
        N = x.size(0)
        h = self.W(x).view(N, self.heads, self.out_dim)        # (N, H, D)
        e_src = (h * self.a_src).sum(-1)                       # (N, H)
        e_dst = (h * self.a_dst).sum(-1)                       # (N, H)
        # attention logits e_ij = LeakyReLU(a_src_i + a_dst_j)
        e = self.leaky(e_src.unsqueeze(1) + e_dst.unsqueeze(0))  # (N, N, H)
        e = e.masked_fill(~adj_mask.unsqueeze(-1), float("-inf"))
        alpha = torch.softmax(e, dim=1)                        # attend over sources
        alpha = torch.nan_to_num(alpha, nan=0.0)
        alpha = self.dropout(alpha)
        out = torch.einsum("ijh,jhd->ihd", alpha, h)          # (N, H, D)
        if self.concat:
            return out.reshape(N, self.heads * self.out_dim)
        return out.mean(dim=1)


class CFGN(nn.Module):
    def __init__(self, embed_dim: int = 64, hidden: int = 64, layers: int = 2,
                 heads: int = 4, tau_c: float = 0.1, edge_out: int = 1):
        super().__init__()
        self.tau_c = tau_c
        self.layers = nn.ModuleList()
        in_dim = embed_dim
        for i in range(layers):
            last = (i == layers - 1)
            self.layers.append(
                GATLayer(in_dim, hidden, heads=heads, concat=not last)
            )
            in_dim = hidden * heads if not last else hidden
        # edge scorer: predicts a causal-link score for an ordered pair (i, j)
        self.edge_mlp = nn.Sequential(
            nn.Linear(2 * in_dim, hidden), nn.ReLU(), nn.Linear(hidden, edge_out)
        )

    def forward(self, z: torch.Tensor, tau: torch.Tensor):
        """Return refined node features and a dense edge-score matrix."""
        w = temporal_causal_adjacency(z, tau, self.tau_c)
        adj_mask = w > 0
        # ensure self-loops so isolated nodes still receive their own signal
        adj_mask = adj_mask | torch.eye(z.size(0), dtype=torch.bool, device=z.device)
        h = z
        for layer in self.layers:
            h = F.elu(layer(h, adj_mask))
        N = h.size(0)
        hi = h.unsqueeze(1).expand(N, N, -1)
        hj = h.unsqueeze(0).expand(N, N, -1)
        edge_logits = self.edge_mlp(torch.cat([hi, hj], dim=-1)).squeeze(-1)
        # respect temporal ordering in the predicted edges as well
        temporal = (tau.unsqueeze(1) < tau.unsqueeze(0))
        edge_logits = edge_logits.masked_fill(~temporal, float("-inf"))
        return h, edge_logits


def extract_timeline(edge_logits: torch.Tensor, threshold: float = 0.0) -> torch.Tensor:
    """Maximum-weight DAG subgraph via thresholding the (already temporally
    ordered) edge scores.  Returns a boolean adjacency of predicted causal edges.
    """
    prob = torch.sigmoid(edge_logits)
    prob = torch.nan_to_num(prob, nan=0.0)
    return prob > torch.sigmoid(torch.tensor(threshold))
