r"""Forensic Evidence Encoder (FEE) -- the device-side TinyML model.

Three stages (Sec. III-A):
  (i)   depthwise-separable 1-D convolution  ->  h_n
  (ii)  bottleneck embedding  z_n = sigmoid(W2 h_n + b2)  in  [0,1]^{d_z}
  (iii) lightweight per-window classifier head  y_hat

GroupNorm (data-independent, per-sample) replaces BatchNorm so that the
per-sample sensitivity argument of Proposition 1 holds.  The released embedding
is clipped to ``||z|| <= C`` which enforces the replace-one sensitivity
``Delta_s <= 2C`` used by the Gaussian mechanism.

Roughly ~37K parameters -> ~37 KB at 8-bit quantisation.
"""
from __future__ import annotations

import torch
import torch.nn as nn
import torch.nn.functional as F


class DepthwiseSeparableConv1d(nn.Module):
    """Depthwise 1-D conv followed by a pointwise (1x1) conv."""

    def __init__(self, in_ch: int, out_ch: int, kernel: int = 3):
        super().__init__()
        pad = kernel // 2
        self.depthwise = nn.Conv1d(in_ch, in_ch, kernel, padding=pad,
                                   groups=in_ch, bias=False)
        self.pointwise = nn.Conv1d(in_ch, out_ch, kernel_size=1, bias=False)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return self.pointwise(self.depthwise(x))


class ForensicEvidenceEncoder(nn.Module):
    def __init__(self, in_channels: int = 1, seq_len: int = 32,
                 conv_channels: int = 16, hidden_dim: int = 64,
                 embed_dim: int = 64, num_classes: int = 2,
                 gn_groups: int = 4, clip_C: float = 1.0):
        super().__init__()
        self.clip_C = clip_C
        self.embed_dim = embed_dim

        self.conv = DepthwiseSeparableConv1d(in_channels, conv_channels, kernel=3)
        # GroupNorm: per-sample statistics, data-independent affine (frozen scale).
        self.norm = nn.GroupNorm(gn_groups, conv_channels, affine=True)
        # Pool to a few temporal positions (not 1) so per-incident waveform
        # structure survives into the embedding for causal-chain reconstruction.
        self.pool_positions = 4
        self.pool = nn.AdaptiveAvgPool1d(self.pool_positions)

        self.to_hidden = nn.Linear(conv_channels * self.pool_positions, hidden_dim)
        self.to_embed = nn.Linear(hidden_dim, embed_dim)   # W2, b2
        self.head = nn.Linear(embed_dim, num_classes)       # per-window classifier

    # -- feature extractor up to the (unclipped) embedding ------------------
    def features(self, x: torch.Tensor) -> torch.Tensor:
        # x: (B, C, L)
        h = self.conv(x)
        h = F.relu(self.norm(h))
        h = self.pool(h).flatten(1)               # (B, conv_channels * positions)
        h = F.relu(self.to_hidden(h))             # (B, hidden_dim)
        z = torch.sigmoid(self.to_embed(h))       # (B, d_z) in [0,1]
        return z

    def clip_embedding(self, z: torch.Tensor) -> torch.Tensor:
        """Project each embedding onto the L2 ball of radius ``clip_C``."""
        norm = z.norm(dim=-1, keepdim=True).clamp_min(1e-12)
        factor = (self.clip_C / norm).clamp_max(1.0)
        return z * factor

    def forward(self, x: torch.Tensor):
        z = self.clip_embedding(self.features(x))
        logits = self.head(z)
        return z, logits

    @torch.no_grad()
    def num_parameters(self) -> int:
        return sum(p.numel() for p in self.parameters())


def sensitivity_bound(clip_C: float) -> float:
    """Replace-one L2 sensitivity of the released embedding: Delta_s <= 2C."""
    return 2.0 * clip_C
