r"""Detection and forensic-specific metrics.

Detection:  precision, recall, F1 (binary anomaly labels).
Forensic:
  * forensic evidence recall -- fraction of ground-truth attack-stage evidence
    records that are preserved *and* correctly attributed (the metric behind the
    18.7% headline at eps=0.5);
  * causal-edge recall -- recall of ground-truth causal edges in the
    reconstructed forensic graph;
  * structural Hamming distance (SHD) between predicted and ground-truth graphs.
"""
from __future__ import annotations

from typing import Dict
import numpy as np


def prf1(y_true: np.ndarray, y_pred: np.ndarray) -> Dict[str, float]:
    tp = int(np.sum((y_pred == 1) & (y_true == 1)))
    fp = int(np.sum((y_pred == 1) & (y_true == 0)))
    fn = int(np.sum((y_pred == 0) & (y_true == 1)))
    prec = tp / (tp + fp) if (tp + fp) else 0.0
    rec = tp / (tp + fn) if (tp + fn) else 0.0
    f1 = 2 * prec * rec / (prec + rec) if (prec + rec) else 0.0
    return {"precision": prec, "recall": rec, "f1": f1}


def evidence_recall(stage_true: np.ndarray, y_pred: np.ndarray,
                    stage_pred_correct: np.ndarray) -> float:
    """Fraction of true attack-stage evidence that is both detected and
    correctly attributed.

    stage_true          : (M,) attack-stage id, -1 for benign
    y_pred              : (M,) predicted anomaly label
    stage_pred_correct  : (M,) bool, whether the stage attribution is correct
    """
    is_evidence = stage_true >= 0
    denom = int(np.sum(is_evidence))
    if denom == 0:
        return 0.0
    preserved = (y_pred == 1) & stage_pred_correct & is_evidence
    return float(np.sum(preserved)) / denom


def causal_edge_recall(pred_adj: np.ndarray, true_adj: np.ndarray) -> float:
    """Recall of ground-truth causal edges."""
    true_edges = int(true_adj.sum())
    if true_edges == 0:
        return 0.0
    hit = int(np.sum((pred_adj > 0) & (true_adj > 0)))
    return hit / true_edges


def structural_hamming_distance(pred_adj: np.ndarray, true_adj: np.ndarray) -> int:
    """Number of edge insertions/deletions to turn pred into true (SHD)."""
    p = (pred_adj > 0).astype(np.int64)
    t = (true_adj > 0).astype(np.int64)
    return int(np.sum(p != t))


def build_stage_ground_truth(stages: np.ndarray, taus: np.ndarray,
                             incidents: np.ndarray | None = None) -> np.ndarray:
    """Ground-truth causal adjacency from attack-stage annotations.

    An edge i->j exists when i and j belong to the same incident, j's stage
    immediately follows i's (stage_j = stage_i + 1), and i precedes j in time
    -- i.e., the known kill-chain progression as a sparse per-incident chain.

    If ``incidents`` is not provided, the edge is defined by consecutive stages
    alone (denser fallback for datasets without incident annotations).
    """
    N = len(stages)
    adj = np.zeros((N, N), dtype=np.int64)
    for i in range(N):
        if stages[i] < 0:
            continue
        for j in range(N):
            same_inc = True if incidents is None else (
                incidents[i] >= 0 and incidents[i] == incidents[j])
            if same_inc and stages[j] == stages[i] + 1 and taus[i] < taus[j]:
                adj[i, j] = 1
    return adj
